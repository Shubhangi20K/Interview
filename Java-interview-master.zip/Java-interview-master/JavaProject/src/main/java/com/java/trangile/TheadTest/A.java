package com.java.trangile.TheadTest;

public class A {

    private int x;
    private int y;
    public A(int x,int y){
        this.x=x;
        this.y=y;
    }
}
