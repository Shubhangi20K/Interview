package com.java.trangile.functionalinter;

public interface FunctionB {
    default void methodTest(){
        System.out.println("methodTest in FunctionB");

    }
}
