package com.java.trangile.TheadTest;

public class B {
    public static void main(String[] args) {
        A a=new A( 10,20);

        A b=a;
        //b.y=23;

    }
}
