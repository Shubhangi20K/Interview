package com.java.trangile.exception;

public class RuntimeExceptionA extends RuntimeException{
    public RuntimeExceptionA(){
        System.out.println("RuntimeExceptionA");
    }

}
