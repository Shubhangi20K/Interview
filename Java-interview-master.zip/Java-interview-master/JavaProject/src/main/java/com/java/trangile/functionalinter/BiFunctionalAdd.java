package com.java.trangile.functionalinter;

import java.util.function.BiFunction;
@FunctionalInterface
public interface BiFunctionalAdd extends BiFunction <String,String,String>{

}
