package com.java.trangile.functionalinter;

public interface FunctionX {
     //void test();
     void testag(String s);
     public default void testdefa(){
         System.out.println("test defalult method");
     }
}
