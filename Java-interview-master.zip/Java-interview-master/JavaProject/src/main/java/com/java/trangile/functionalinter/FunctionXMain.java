package com.java.trangile.functionalinter;

public class FunctionXMain {
    public static void main(String[] args) {
        FunctionX x=(s)->System.out.println("test data"+s);
        x.testag("paoa");
    }
}
