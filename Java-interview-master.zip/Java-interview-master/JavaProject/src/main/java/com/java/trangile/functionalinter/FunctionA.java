package com.java.trangile.functionalinter;

public interface FunctionA {

    default void methodTest(){
        System.out.println("methodTest in FunctionA");

    }
}
