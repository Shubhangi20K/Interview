package com.java.trangile.functionalinter;
@FunctionalInterface
public interface I {

    String test();
}
