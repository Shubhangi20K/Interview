package com.java.trangile.photon;

public class Cunsumer {
    public static void main(String[] args) {

    }
}
