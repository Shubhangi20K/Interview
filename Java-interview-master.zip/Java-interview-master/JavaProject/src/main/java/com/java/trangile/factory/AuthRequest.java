package com.java.trangile.factory;

public class AuthRequest {

    private String oauthAccessToken;

    private String oauthSecretToken;

    private AuthProvider provider;
}
