package com.java.trangile;

public abstract class A {

    int x;
    public A(int x){
        this.x=x;
    }

    public abstract void m1(int x);

}
