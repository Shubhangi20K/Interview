package com.java.trangile.singleton;

public class SessionFactory {
}
