package com.java.trangile.factory;

public enum AuthProvider {
    TWITTER, LINKEDIN, FACEBOOK, GOOGLE, APPLE;
}
