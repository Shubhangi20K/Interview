package com.java.trangile.exception;

public class CheckExceptionA extends Exception{

    public CheckExceptionA(){
        System.out.println("CheckExceptionA");
    }
}
