package com.java.trangile.program;

public class StringTest {
    public static void main(String[] args) {
        String s1="abc";
        System.out.println(s1.substring(0,0));
        System.out.println(s1.substring( 1));

    }


    public static void missingnu(int a[],int b[],int k,int l){








    }
}
