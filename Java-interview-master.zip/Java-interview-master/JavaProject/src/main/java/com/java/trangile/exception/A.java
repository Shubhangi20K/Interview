package com.java.trangile.exception;

import java.io.IOException;

public class A {

    public void m1()  {
        System.out.println("A test class m1 ");
    }
}
