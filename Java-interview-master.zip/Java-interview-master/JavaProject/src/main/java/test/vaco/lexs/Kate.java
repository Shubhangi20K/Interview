package test.vaco.lexs;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class Kate {
    public static void main(String[] args) {

    }
}
